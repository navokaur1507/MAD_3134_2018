<?php
//@TODO: put PHP LOGIC


//QUESTION- for this page
// 2)yes
// 3) no
$name = $_POST["name"];
$desc = $_POST["desc"];
$price = $_POST["price"];
//if you picked A) reason why!
//if you picked A) reason why!
// 1. WHAT IS YOUR INFO?
	// 		host ? db name? db user? db password?
	$dbhost = "localhost";		// address of your database
	$dbuser = "root";
	$dbpassword = "";			// on MAMP, this is "root"
	$dbname = "ecommerce";
	
	// 2.  CONNECT TO THE DATABASE
	$conn = mysqli_connect($dbhost,$dbuser,$dbpassword,$dbname);
	
	// 3. MAKE a SQL QUERY
	$query = 'INSERT INTO PRODUCT (name,product_name,price)' . 'VALUES ("' .$name . '","' . $desc . '"."' . $price . '")';
	//4. get results
	$results = mysqli_query($conn, @query);
	
	if($results) {
		echo "OKAY <br>";
	}
	else {
		echo "BAD <br>";
		echo mysqli_error($conn);
	}
	
	
?>

<!DOCTYPE html5>
<html>
<head>
	<link rel="stylesheet" href="https://fonts.googleapis.com/icon?family=Material+Icons">
	<link rel="stylesheet" href="https://code.getmdl.io/1.3.0/material.indigo-pink.min.css">
	<script defer src="https://code.getmdl.io/1.3.0/material.min.js"></script>
</head>
<body>

	<div class="mdl-grid">
	  <div class="mdl-cell mdl-cell--12-col">
	  	<h1> Add Product </h1>
		<h2> Enter new products: </h2>
	  	  		


		<!-- form -->
		<form action="product.php" method="POST">
		<form action="#">
		  <div class="mdl-textfield mdl-js-textfield mdl-textfield--floating-label">
			<input name="name" class="mdl-textfield__input" type="text" id="sample3">
			<label class="mdl-textfield__label" for="sample3">Product Name</label>
		  </div>
		  <br>
		  <div class="mdl-textfield mdl-js-textfield mdl-textfield--floating-label">
			<input name="desc" class="mdl-textfield__input" type="text" id="sample3">
			<label class="mdl-textfield__label" for="sample3">Description</label>
		  </div>
		  <br>
		  <div class="mdl-textfield mdl-js-textfield mdl-textfield--floating-label">
			<input name="desc" class="mdl-textfield__input" type="text" pattern="-?[0-9]*(\.[0-9]+)?" id="sample2">
			<label class="mdl-textfield__label" for="sample2">Price</label>
			<span class="mdl-textfield__error">Input is not a number!</span>
		  </div>
		  <br>
		  <button href="show-products.php" class="mdl-button mdl-js-button mdl-button--raised mdl-button--accent">
			+ Add Product
		  </button>
		</form>
		
		<br>
		
		<a href="donut.php" class="mdl-button mdl-js-button mdl-button--raised mdl-button--colored">
			 Go Back 
		</a>
	  </div>
	</div>



	
	<br>
	
	
	<br>
	


	<br>
	
</body>
</html>


<?php
	// write the code to connect to the db
		
	// 1. WHAT IS YOUR INFO?
	// 		host ? db name? db user? db password?
	$dbhost = "localhost";		// address of your database
	$dbuser = "root";
	$dbpassword = "";			// on MAMP, this is "root"
	$dbname = "employee";
	
	// 2.  CONNECT TO THE DATABASE
	$conn = mysqli_connect($dbhost,$dbuser,$dbpassword,$dbname);
	
	// 3.  MAKE a SQL QUERY 
	
	// make the query
	$query = "SELECT * from product";
	
	// 4. SEND QUERY TO DB & GET RESULTS 
	$results = mysqli_query($conn, $query);
	
	// 5. SHOW THE DATABASE RESULTS SOMEWHERE
		
	// loop through the database results
	while( $product = mysqli_fetch_assoc($results) ) {
		// show all row data
		print_r($product);
		echo "<br>";
	
		// print people's first names
		echo "<span style='color:red'>";
		echo $product["name"];
		echo "</span> <br>";
	}
		
	// 6. DISCONNECT FROM DATABSE
	mysqli_free_result($results); // clean up your row variable
	mysqli_close($conn);	// close connection to db
?>