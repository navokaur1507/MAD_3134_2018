
<h1>php basics</h1>
<?php
//comments
//your code goes hgere
//variablenames

$x = 25;
$y = "nav";
$z = 30.9;
$h = $x;

//output tot he screen
//console.log(..)

echo "<h2 style='color:red'> dd </h2>";
//echo $x;

echo "hello" . "goodbye" . "timmies" . "donut";
echo $x + $z;
//if statements
$abc = 30;
if ($abc < 25) {
	echo "HELLO";
}
else if ($abc > 27) {
	echo "APPLE";
}
else {
	echo "GOODBYE";
}

// for-loop -> while loop?
// for - loop:
//loop thatreaps afixed number oflines
// -you tell the loop how manytimes you wanna loop
//while:
//-loop that repeats until a conditionismet
// - doesn't stopuntil a condition is metaphone

// foor loop
//for ($i = 0; $i < 5; $i++) {
	//echo "HELLO! <br>";
//}

// while loop
$b= 5;
while ($b < 8) {
	echo "BYE! <br>";
	$b = $b + 1;
}

//function -- create a function
function sayHello() {
	echo "ABACAXI <br>";
	echo "ANANAS <br>";
	echo "PNEAPPLE <br>";
}

function fruit($language) {
	if ($lang == "gurati") {
		echo "ANANAS";
	}
	else if ($lang == "malyalam") {
		echo "KAITHACHAKA";
	}
	else if ($lang == "br") {
		echo "ABACAXI";
	}
	else if ($lang == "viet") {
		echo "JUA";
	}
	else {
		sayHELLO();
	}
}

// USING A FUNCTION
//sayHELLO();
/*
$w ="viet"
pineaplle($w);
*/
//pinapple("english");

//Arrays

// create empty arrays
$animals = [];
$animals = array();

// add thing to the array
$animals[0] ="dog";
$animals[1] ="cat";

//another way to add array
// this will add tot he end of the array
array_push($animals, "fox");

// length of an array
echo " The length of array is:  ". count($animals). "<br>";

for ($j = 0; $j < count($animals); $j++) {
	echo "Hello : " . $animals[$j] . "<br>";
}

// ASSOCIATIVE ARRAY ->
$easy = array(					//ZAY
"en" => "easy",
"fr" => "facile",
"vt" => "facil",
"my" => "elupam",
"gu" => "saral",
"pn" => "sokha"
);
//print everything
print_r($easy);

//single item from dictionary
echo $easy["my"] . "<br>";

//looping through an associate array 
//foreach(___as__=>___) {
//}

foreach($easy as $K => $V) {
	echo "Key is: " . $K . "<br>";
	echo "Value is: " . $V . "</br>";
	echo "----" . "</br>";
}

//for ($j = 5; $j <10; $j++) {
	//array_push($animals, "cow");
//shiyard -> raposa

//array
//printt_r($animals);


//clear your array
//$animals = [];  // $animals =array();



	

?>

