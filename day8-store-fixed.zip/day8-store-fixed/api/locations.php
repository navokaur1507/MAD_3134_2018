<?php
echo "Hello";
// 1. connect to your database

    $dbhost = "localhost";		// address of your database
	$dbuser = "root";
	$dbpassword = "";			// on MAMP, this is "root"
	$dbname = "store";

	
	$conn = mysqli_connect($dbhost,$dbuser,$dbpassword,$dbname);
	
	$query = "SELECT * from locations";
	
	
     // 2. grab all the locations
        $results = mysqli_query($conn, $query);
	
	 $stores= [];
	while( $item = mysqli_fetch_assoc($results) ) {
		//add all items to the array
		array_push($stores, $item);
		
	}

     // 3. return all the locations as JSON

     // tell the browser we're sending json
	 header("content-Type: application/json");
	 
	 //convert our array into a json dictionary
	 $json = json_encode($stores);
	 
	 // deal with any errors during conversation
	 if($json === false) {
		 $errorMessage = array("error"=>json_last_error_msg());
		 $json = json_encode($json);
		 http_response_code(500);
	 }
		 
		 //send the jsaon dictionary to the browser
		 echo $json;
?>
