<!DOCTYPE html>
<html>
	<head>
		<meta charset="utf-8">
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<title>Hello Bulma!</title>
		<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bulma/0.7.1/css/bulma.min.css">
		<script defer src="https://use.fontawesome.com/releases/v5.0.7/js/all.js"></script>
	</head>
	<body>
	<section class="section">
		<div class="container">
			<h1 class="title">
				Order Confirmation
			</h1>

			<?php
			
				// test for error conditions
				$name = $_POST["firstName"];
				$email = $_POST["email"];
				$cc = $_POST["cc"];
				
				// check if fields are blank
				if (empty($name) || empty($email) || empty($cc)) {
					echo "<br> Name, email or cc field is blank! <br>";
				}
				// check if credit card is valid
				else if (strlen($cc) != 16) {
					echo "Credit card number must be 16 digits. <br>";	
				}
				else {
					if (ccIsValid($cc) == false) {
						echo "Credit card is INVALID!";
					}
					else {
						// if all conditions PASS, then SHOW SUCCESS MESSAGE
						echo "Hey, " . $name ."! <br>";
						echo "Thanks for your order. <br>";
						echo "We sent a copy of your receipt to: ";
						echo "<span style='color:#184999; text-decoration:none'>";
						echo $email;
						echo "</span>";
					}
				}
					
				
				function ccIsValid($cc) {
					// 0. reverse the CC number so all the 
					//   positions match the algorithm
					$reversed = strrev($cc);
					
					// 1. loop throungh the numbers in the cc
					$total = 0;
					
					for ($i=0; $i< 16; $i++) {
						// @debug: print out each character

						if ($i % 2 == 1) {
							// do multiply + convert
							$num = $reversed[$i] * 2;
							if ($num > 9) {
								//conversion
								$num = $num - 9;
							}
						}
						else {
							//do nothing
							$num = $reversed[$i];
						}
						
						
						// 3. add to the total!
						$total = $total + $num;
					
					} // end for loop
								
					// 4. after looping, do total % 10
					if ($total % 10 == 0) {
						// cc is valid
						return true;
					}
					else {
						//cc is invalid
						return false;
					}
				
				}	// end of function
				
			
			

			?>
		<br>
		<a href="checkout.php" > Go Back </a>	
		
    </div>
  </section>
  </body>
</html>