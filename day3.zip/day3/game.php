<?php

if ($_SERVER["REQUEST_METHOD"] == "GET") {
}
else if($_SERVER["REQUEST_METHOD"] == "POST"){
	// check the word!
	$guess = $_POST["guess"];
	echo $guess . "<br>";
	
	//2. compare the guess to the password;
	if ($guess == $password) {
		echo "WINNER";
	}
	else{
		$correct = 0;
	for($i = 0; $i < 4; $i++) {
		if ($guess[$i] == $password[$i]) {
			$correct = $correct + 1;
		}
	}
	echo "Number of correct letters: " . $correct;
	}
}
   // read words from a file
    $file = file_get_contents("simplewords.text", true);
    $words = str_word_count($file, 1);
	
	//print_r($words);
	
	//randomly pick word from a array?
	//print_r(array_rand($words, 10));
	
	//get lenght of array
	$lenght = count($simplewords);
	$picked = [];
	$choices = [];
	for ($i=0; $i<10; $i++) {
		while(1)
		{
			//pick a random number
			$randomNumber = rand (0, $trenght-1);
		// check if you picked this position already
		if (in_array($randomNumber, $picked)== true) {
			//skip
			continue;
		}
		else {
			array_push($choices, $words[$words]);
			break;
		}
	}
	// pick a random word to be a password!

	$x = rand(0,10);
	$x = rand(0, count($choices)-1);
	$password = $choices[x];
	
	for ($j=0; $j < count ($choices); $j++) {
		// if you picked the postion already,
		// then pick a new random Number
		$randomNumber = rand ( 0, $trenght-1);
	    echo $simplewords[$randomNumber] . "<br>";
		}
		 echo "random password" . $password . "<br>";
	
    
	
?>	
<html>
<head></head>
<body>
</body>
</html>