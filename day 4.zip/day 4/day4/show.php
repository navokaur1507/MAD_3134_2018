<h1> Connecting to a Database </h1>
<?php
     // write hte code to connect to the db
	 
	 
	 // 1. what is your database info?
	 // db name? db password? db user?
	 $dbhost = "localhost";    //address of your database
	 $dbuser = "root";
	 $dbpassword = "";       
	 $dbname = "employees";
	 
	
	// 2. CONNECT TO THE Database
	$conn = mysqli_connect($dbhost,$dbuser,$dbpassword,$dbname);
	
	// 3. MAKE a SQL QUERY
	$query = "SELECT * from employees";   // when select query
	
	//4. SEND QUERY TO DB AND GET RESULT FROM THE Database
	$results = mysqli_query($conn,$query);    //send to db where  - it gonna come back and store
	
	// 5. SHOW THE DATABASE THE RESULTS SOMEWHERE
	// var_dump($results);   
	
	//LOOP through the database results
	while($employees= mysqli_fetch_assoc($results)) {
		//print_r($employees);
		echo "<br>";
		
		//print people's first name
		echo $employees["firstname"] . "<br>";
		echo "<span style='color:red'>";
	}
	
	
	// 6. DISCONNECT FROM THE DATABASE
	mysqli_free_result($results);  //clean up your row variable
	mysqli_close($conn);  // close connection to db
	
	?>